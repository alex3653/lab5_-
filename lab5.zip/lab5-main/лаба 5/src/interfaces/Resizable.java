package interfaces;

public interface Resizable {

    void resize(int percent);

}

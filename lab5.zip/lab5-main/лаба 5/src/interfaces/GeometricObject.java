package interfaces;

public interface GeometricObject {

    double getPerimeter();

    double getArea();

}
